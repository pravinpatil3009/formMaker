$Id: README.txt,v 1.2.6.1 2008/09/28 20:27:10 acm Exp $

This module allows administrators to set maximum lengths for the body
fields of content types, as well as activating a Java Script count down 
for CCK text fields.

Maximum size for the body and title are on the content type's edit page.
Enabling the JS count down for CCK fields is done on the fields respective
configuration pages.

Any questions or problems please use the issue queue via the project page
http://drupal.org/project/maxlength